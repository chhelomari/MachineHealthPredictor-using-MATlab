function gui()
    f = figure('Name', 'Machine Health Checker', 'Position', [100, 100, 900, 500]);

    uicontrol('Style', 'text', 'Position', [200, 440, 500, 30], 'String', 'Welcome to the Machine Health Checker!', ...
        'FontSize', 16, 'FontWeight', 'bold', 'ForegroundColor', 'blue', 'BackgroundColor', 'white', 'HorizontalAlignment', 'center');

    uicontrol('Style', 'text', 'Position', [50, 380, 100, 30], 'String', 'Machine Type:', 'FontSize', 12, 'FontWeight', 'bold');
    machineTypeDropdown = uicontrol('Style', 'popupmenu', 'Position', [150, 380, 200, 30], 'String', {'Electrical Machine', 'Mechanical Machine', 'Hydraulic Machine', 'Pneumatic Machine'}, 'FontSize', 12);

    uicontrol('Style', 'text', 'Position', [50, 320, 100, 30], 'String', 'Temperature:', 'FontSize', 12, 'FontWeight', 'bold');  % Adjusted font size
    tempInput = uicontrol('Style', 'edit', 'Position', [150, 320, 100, 30], 'FontSize', 12);

    uicontrol('Style', 'text', 'Position', [50, 260, 100, 30], 'String', 'Vibration:', 'FontSize', 12, 'FontWeight', 'bold');  % Adjusted font size
    vibrationInput = uicontrol('Style', 'edit', 'Position', [150, 260, 100, 30], 'FontSize', 12);

    uicontrol('Style', 'text', 'Position', [50, 200, 100, 30], 'String', 'Pressure:', 'FontSize', 12, 'FontWeight', 'bold');  % Adjusted font size
    pressureInput = uicontrol('Style', 'edit', 'Position', [150, 200, 100, 30], 'FontSize', 12);

    ax = axes(f, 'Position', [0.5, 0.2, 0.4, 0.6]);

    uicontrol('Style', 'pushbutton', 'Position', [50, 40, 150, 40], 'String', 'Check Machine', 'FontSize', 12, 'FontWeight', 'bold', ...
        'BackgroundColor', [0.3, 0.7, 0.3], 'Callback', @checkMachine);

    uicontrol('Style', 'pushbutton', 'Position', [210, 40, 150, 40], 'String', 'Clear All', 'FontSize', 12, 'FontWeight', 'bold', ...
        'BackgroundColor', [0.3, 0.3, 0.7], 'Callback', @clearAll);

    machineData = readtable('machine_standards.xlsx');
    
    function checkMachine(~, ~)
        machineType = machineTypeDropdown.Value;
        temp = str2double(get(tempInput, 'String'));
        vibration = str2double(get(vibrationInput, 'String'));
        pressure = str2double(get(pressureInput, 'String'));

        if isempty(temp) || isempty(vibration) || isempty(pressure) || isnan(temp) || isnan(vibration) || isnan(pressure)
            msgbox('Please enter the required values !', 'Error', 'error');
            return;
        end

        machineTypes = machineData.MachineType;
        selectedMachineType = machineTypes{machineType}; 
        selectedMachineRow = machineData(strcmp(machineData.MachineType, selectedMachineType), :);

        normalTemp = selectedMachineRow.MaxTemperature;
        normalVibration = selectedMachineRow.MaxVibration;
        normalPressure = selectedMachineRow.MaxPressure;

        if temp > normalTemp || vibration > normalVibration || pressure > normalPressure
            msgbox('The machine is FAULTY!', 'Warning', 'warn');
        else
            msgbox('The machine is NORMAL.', 'Success', 'help');
        end

        cla(ax);
        hold(ax, 'on');
        plot(ax, [0, 1], [normalTemp, normalTemp], '--r', 'LineWidth', 2); 
        plot(ax, [0, 1], [normalVibration, normalVibration], '--g', 'LineWidth', 2); 
        plot(ax, [0, 1], [normalPressure, normalPressure], '--b', 'LineWidth', 2); 
        scatter(ax, 0.5, temp, 100, 'r', 'filled'); 
        scatter(ax, 0.5, vibration, 100, 'g', 'filled');
        scatter(ax, 0.5, pressure, 100, 'b', 'filled'); 

        legend(ax, 'Normal Temperature', 'Normal Vibration', 'Normal Pressure', 'Location', 'northeastoutside');
        hold(ax, 'off');
    end

    function clearAll(~, ~)
        
        set(tempInput, 'String', '');
        set(vibrationInput, 'String', '');
        set(pressureInput, 'String', '');
        cla(ax);
    end
end

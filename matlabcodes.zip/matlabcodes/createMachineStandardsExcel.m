function createMachineStandardsExcel()
    machineData = {
        'Machine Type', 'Max Temperature', 'Max Vibration', 'Max Pressure';
        'Electrical Machine', 85, 6, 220;
        'Mechanical Machine', 95, 7, 250;
        'Hydraulic Machine', 90, 5, 200;
        'Pneumatic Machine', 80, 4, 180;
    };

    machineTable = cell2table(machineData(2:end, :), 'VariableNames', machineData(1, :));

    writetable(machineTable, 'machine_standards.xlsx');

    disp('Excel file created successfully!');
end
function trainModel()

    data = readtable('machine_standards.xlsx', 'PreserveVariableNames', true);  

    features = data{:, 2:4};  
    labels = data{:, 1};  

    model = fitctree(features, labels);

    save('trainedModel.mat', 'model');  

    disp('Model trained and saved as trainedModel.mat');
end
